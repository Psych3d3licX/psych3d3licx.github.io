## Psych3d3licX Website Projekt

### Übersicht
Diese Website präsentiert das Projekt **Psych3d3licX** – Musik mit Haltung, Tiefe und rebellischer Energie.

### Struktur
- `README.md`
- `index.html` – Hauptseite der Website
- `style.css` – Stylesheet für Layout und Design
- `scripts.js` – Interaktive Funktionen (Tabs, Popups, E-Mail-Schutz)
- `robots.txt` – Suchmaschinenrichtlinien
- `sitemap.xml` – Strukturübersicht für Suchmaschinen
- `images/` – Headerbild, Profilbild, Albumcover

### Hauptfeatures
- Responsive Design für Desktop und Mobile
- Fokus auf Barrierefreiheit (ARIA-Attribute, Lazy Loading, Popup-Fokus)
- SEO-Optimierungen (Meta-Description, Sitemap-Integration)
- Sauber strukturierter und erweiterbarer Code
- Dark Mode und klarer visuell rebellischer Stil

### Anforderungen
- Moderner Browser (Chrome, Firefox, Edge, Safari)
- JavaScript aktiviert

### Hinweise
- Kein externes Framework notwendig
- Keine Server-seitige Verarbeitung – reine HTML/CSS/JS Website
- Optimiert für schnelles Laden und gute Lesbarkeit

---

**Erstellt 2025 – Psych3d3licX – Musik gegen die Lähmung.** 🔥
